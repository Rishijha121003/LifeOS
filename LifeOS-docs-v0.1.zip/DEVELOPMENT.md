# LifeOS — Development Rules

## 1. Development Philosophy

LifeOS is a learning-first project.

The developer must understand the code being added.

AI coding tools may accelerate implementation, but they must not replace understanding.

## 2. Build Order

1. Project setup
2. Database connection
3. Task model
4. Pydantic schemas
5. CRUD service
6. Task API
7. API testing
8. Frontend setup
9. Task UI
10. Dashboard
11. Responsive polish
12. Integration testing

## 3. Working Rule

Before changing code:
- inspect existing code
- understand dependencies
- identify the smallest required change

After a change:
- run the application
- test the affected feature
- check logs/errors
- avoid accumulating untested changes

## 4. Antigravity Usage

Antigravity may be used for:
- boilerplate
- repetitive implementation
- debugging assistance
- refactoring suggestions
- test generation
- UI implementation after the UI specification is approved

Do not blindly accept generated architecture or business logic.

## 5. Git

Use small, meaningful commits.

Example:
- feat: add task model
- feat: add task CRUD API
- feat: add dashboard task list
- fix: validate due time
- style: improve task card spacing

## 6. Definition of Done

A feature is not done merely because code exists.

It must:
- work
- be tested
- handle expected errors
- have sensible UI states
- not break existing functionality
