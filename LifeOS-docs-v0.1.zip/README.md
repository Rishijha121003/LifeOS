# LifeOS

LifeOS is a personal productivity application designed for daily use.

## V0.1 Goal

Build a polished, simple task-management system that answers:

> What do I need to do today?

V0.1 includes:
- Dashboard
- Tasks
- Today / Upcoming / Completed views
- Priority
- Due date/time
- Task completion
- Basic statistics

V0.1 does NOT include AI, automatic replanning, finance, habits, calendar integrations, notifications, or complex analytics.

## Product Philosophy

Build the smallest useful version first. Use the application personally, observe real problems, and let later versions emerge from actual usage.

## Future Direction

Plan → Execute → Track → Replan → Analyze → Improve
