# LifeOS — Architecture

## 1. Architecture Goal

Keep V0.1 simple, modular, testable, and easy to extend.

## 2. High-Level Architecture

Frontend
    ↓
REST API
    ↓
FastAPI
    ↓
Service / Business Logic
    ↓
SQLAlchemy
    ↓
PostgreSQL

## 3. Backend Layers

### API / Router Layer
Responsible for:
- HTTP routes
- Request/response handling
- Authentication later
- Input validation boundaries

### Schema Layer
Pydantic models for:
- Create task
- Update task
- Task response

### Service Layer
Contains business rules such as:
- Creating tasks
- Updating tasks
- Completing tasks
- Filtering tasks
- Calculating task statistics

### Repository / Data Access
Keep database access organized and reusable.

### Model Layer
SQLAlchemy database models.

## 4. Frontend Structure

Prefer reusable components:
- Layout
- Sidebar/navigation
- Dashboard
- Task list
- Task item/card
- Task form/modal
- Statistics cards
- Toast/feedback components
- Empty states

Avoid a single giant page component.

## 5. Future Compatibility

The architecture should allow future modules:
- expenses
- habits
- study
- analytics
- replanning engine
- AI assistant
- notifications

Do not implement them in V0.1.

## 6. Core Principle

Do not over-engineer for hypothetical future requirements. Design clean boundaries, but implement only current requirements.
