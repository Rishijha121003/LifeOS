# LifeOS — Roadmap

## V0.1 — Foundation
- Tasks
- Dashboard
- Today
- Upcoming
- Completed
- polished UI

## V0.2 — Personal Tracking
Potentially:
- expenses
- habits
- study tracking

Features should be selected based on real usage of V0.1.

## V0.3 — Analytics
Potentially:
- weekly review
- completion trends
- study trends
- expense trends

## V0.4 — Dynamic Replanning
Core idea:

Current time
+ today's plan
+ completed tasks
+ pending tasks
+ task priority
+ estimated duration
+ remaining available time

→ generate a realistic revised plan.

Tasks that cannot reasonably fit should be carried forward.

## V0.5 — AI Assistant
AI can help interpret the user's situation and explain recommendations.

The deterministic scheduling/replanning logic should remain understandable and testable.

## V1.0 — Stable Personal Product
A reliable daily-use version.

## Future

Potential:
- calendar integration
- notifications
- intelligent pattern detection
- personalized insights
- multi-device synchronization
