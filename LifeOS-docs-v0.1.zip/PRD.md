# LifeOS — Product Requirements Document

## 1. Vision

LifeOS is a personal daily-life management system. It should eventually reduce the mental effort required to decide what to do, track what was done, and recover when plans change.

## 2. V0.1 Objective

Create a reliable and polished daily task manager.

## 3. Target User

Initial target user: the developer himself, using the application every day.

The product should solve real daily problems rather than demonstrate a large number of features.

## 4. V0.1 Features

### Dashboard
- Today's date
- Today's task count
- Completed count
- Pending count
- Completion percentage
- Today's tasks
- Quick add task

### Tasks
- Create
- Read
- Update
- Delete
- Complete/uncomplete
- Title
- Description
- Due date
- Due time
- Priority

### Views
- Today
- Upcoming
- Completed

### UX
- Empty states
- Loading states
- Error states
- Success feedback
- Responsive design

## 5. Explicitly Out of Scope

- AI assistant
- Automatic schedule replanning
- Expenses
- Habit tracking
- Study tracking
- Calendar sync
- Push notifications
- Multi-user collaboration
- Complex analytics

## 6. Success Criteria

V0.1 is successful when the developer can use it every day for at least one week without needing a separate task manager for the same basic workflow.
